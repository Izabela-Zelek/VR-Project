var searchData=
[
  ['largeitem_0',['LargeItem',['../class_large_item.html',1,'']]]
];
