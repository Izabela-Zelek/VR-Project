var searchData=
[
  ['newday_0',['newDay',['../class_time_controller.html#a82e2a336c9348eb0b9527ec4745f7753',1,'TimeController']]]
];
